#!/bin/bash

#######################################################################
#
#       Script Name     :       delete_lifeCycle.sh
#       Description     :       ライフサイクルで削除されないファイルを削除するためのシェル
#       ATTENTION       :
#       param file_name :       ファイル名
#       param directory :       ディレクトリパス
#       param csv       :       読み込むCSVファイル
#       param date      :       当日日付
#       param array     :       CSVから取得したデータを格納
#       param format    :
#       param lifecycle :
#       param comparison_data   :
#       param           :
########################################################################
root="spmpro-s3-logarchive-bucket"
endpoint="http://192.168.56.105:9090"
#csv="../sample.csv"
csv="../createList2.csv"
array=()
comparison_data="null"
white_list=()
delete_list=()
file_name_array=()
delete_array=()
yyyymmdd="null"
save_flg="0"
file_list=()
only1=()
#バッチ開始処理
file_name="$(basename $0)"
echo "${file_name}を開始しました" >> ${file_name%.*}.txt

function search (){
IFS=$'\n'
#両方の配列に含まれる項目を抜き出す
both=(`{ echo "${file_list[*]}"; echo "${white_list[*]}"; } | sort | uniq -d`)

#file_listから重複部分を取り除くとfile_listには含まれるが
#white_listには含まれない項目を取り出せる
only1=(`{ echo "${file_list[*]}"; echo "${both[*]}"; } | sort | uniq -u`)
echo "削除対象出力--------------------------------"
echo "${only1[*]}" >> only1.txt
}


#ファイルを削除するファンクション
function file_delete () {
    echo "削除処理に入りました"
    for name in ${only1[@]};  do
        echo "削除開始"
        echo "${name}"
        #echo aws --endpoint-url ${endpoint} s3 rm s3://${root}$1/ --recursive --exclude "*" --include "${name}" --dryrun > delete_file.log
        echo `aws --endpoint-url ${endpoint} s3 rm s3://${root}/$1/ --recursive --exclude "*" --include "${name}" --dryrun` >> delete_file.log
    done
}
function aaa (){
#フォーマットとライフサイクルを分解
    lifecycle=`echo $1| cut -d ',' -f 2`
    lifecycle=`echo ${lifecycle} | sed -e "s/[\r\n]\+//g"`
    format=`echo $1 | cut -d ',' -f 1`

    #  ディレクトリ名とファイル名をそれぞれ変数に入れる
    dir=$(dirname ${format})
    file=`echo ${format#${dir}/}`
    echo "今回処理するファイルパターン：${file}"
    file_name_array+=(`echo ${file}`)
}

#CSVから削除対象の情報を取得　取得先deleteList2.csv
while read row; do
  array+=(`echo ${row}`)
done < ${csv}
#配列初期化
white_list=()
file_list=()
#削除条件のデータ配列を0～Nでループ
for i in "${array[@]}";  do
    #カウンター定義
    let counter++

    aaa ${i}
    if [[ ${comparison_data} == ${dir} ]]
        then
            : # 何もしない
            echo "skip"
        else
            #   ディレクトリを検索する
            #echo "ディレクトリ内のファイル名を取得中"
            echo `aws --endpoint-url http://192.168.56.105:9090 s3 ls s3://${root}${dir}/ --recursive | awk '{$1=$2=$3=""; print $0}' | sed 's/^[ \t]*//'` >> search_file.txt
    fi
            #   取得したファイル名のYYYYMMDDの部分を正規表現に変更
            file=`echo ${file//"YYYYMMDD"/"20[0-9]{2}[0-1][0-9][0-3][0-9]"}`
            #   取得したファイル名をlist.txtでgrepにかける。結果をファイルに出力
            echo `grep -Eo ${file} search_file.txt` > file_list.txt
            #  マッチしたファイル名から当日(前日 - ライフサイクル)のものをsave_arrayに格納
            yyyymmdd=`date '+%Y%m%d' -d "- ${lifecycle} day"`

            #save_array+="echo `grep 当日(前日 - ライフサイクル)する`"
            echo "${lifecycle}"
            for j in `seq 0 ${lifecycle}`; do
                #seqコマンドでライフサイクルを-1づつ繰り返しライフサイクル分の日付を取得する
                yyyymmdd=`date "+%Y%m%d" -d " - ${j} day"`
                #ここに未来日を判定するif分を設置
                #上記で取得したyyyymmddをファイルパターンのYYYYMMDDに当てはめる
                file_name=`echo "${file//"20[0-9]{2}[0-1][0-9][0-3][0-9]"/${yyyymmdd}}"`
                #YYYYMMDDをライフサイクル期間の日付に置換したフォーマットとファイルパターンで抽出したファイル名を突き合わせ、一致した物（ライフサイクル内の物）はwhite_listに格納
                white_list+=(`grep -o ${file_name} file_list.txt`)
            done

            #比較用変数にディレクトリ名を格納
            comparison_data="${dir}"
            #ファイル一覧を読み込み
            file_name_csv="./file_list.txt"
            while read row; do
                file_list+=(`echo ${row}`)
            done < ${file_name_csv}
            #検索関数を呼び出す
            search

    echo "処理終了"
done
for i in "${white_list[@]}";  do
    echo "${i}" >> i.txt
done
