#!/bin/bash
#
#######################################################################
#
#       Script Name     :       deletefile.sh
#       Description     :       Ⅱ-1．不要ファイル削除処理(機能削除等) 実行シェル
#       ATTENTION       :       本番使用時は awsコマンドの --dryrunオプションを削除してください。
#                               本番使用時は awsコマンドの endpoint_url=http..オプションを削除してください。
########################################################################

root="spmpro-s3-logarchive-bucket"
endpoint="http://192.168.56.105:9090"

csv="../deleteList.csv"

echo "#####不要ファイル削除処理(機能削除等)を実行します。"
rm "log.txt"

counter=0
array=()

while read row; do
	array+=(`echo ${row}`)
done < ${csv}

for i in "${array[@]}"
do
	#echo ${i}
	dir=$(dirname ${i})
	file=`echo ${i#${dir}/}`
	
	
	aws --endpoint-url ${endpoint} s3 rm s3://${root}${dir} --recursive --exclude "*" --include "${file}" --dryrun>>log.txt
	ret=`echo $?`
	if [ $ret = 0 ]; then
		let counter++
	fi
done

echo "#####不要ファイル削除処理(機能削除等) 削除数：${counter}"