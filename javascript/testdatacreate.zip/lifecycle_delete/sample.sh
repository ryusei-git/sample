#!/bin/bash

var="abcdef abcdef xyz"
echo ${var/abc/XXX}
echo ${var//abc/XXXXX}