#!/bin/bash

#######################################################################
#
#       Script Name     :       delete_lifeCycle.sh
#       Description     :       ライフサイクルで削除されないファイルを削除するためのシェル
#       ATTENTION       :
#       param file_name :       ファイル名
#       param directory :       ディレクトリパス
#       param csv       :       読み込むCSVファイル
#       param date      :       当日日付
#       param array     :       CSVから取得したデータを格納
#       param format    :
#       param lifecycle :
#       param comparison_data   :
#       param           :
########################################################################
root="spmpro-s3-logarchive-bucket"
endpoint="http://192.168.56.105:9090"
csv="../deleteList2.csv"
array=()
comparison_data= "null"

#バッチ開始処理
file_name="$(basename $0)"
echo "${file_name}を開始しました" >> ${file_name%.*}.txt

#CSVから削除対象の情報を取得　取得先deleteList2.csv
while read row; do
  array+=(`echo ${row}`)
done < ${csv}

#削除条件のデータ配列を0～Nでループ
for i in "${array[@]}";  do
    #カウンター定義
    let counter++

    #フォーマットとライフサイクルを分解
    lifecycle=`echo ${i} | cut -d ',' -f 2`
    lifecycle=`echo ${lifecycle} | sed -e "s/[\r\n]\+//g"`
    format=`echo ${i} | cut -d ',' -f 1`

    #  ディレクトリ名とファイル名をそれぞれ変数に入れる
    dir=$(dirname ${format})
    file=`echo ${format#${dir}/}`

    #ディレクトリが同一であれば処理をスキップ
    if [[ ${comparison_data} == ${dir} ]]
    then
        echo "重複したディレクトリのためスキップ"
    else
        #   ディレクトリを検索する
        echo "ディレクトリ内のファイル名を取得中"
        echo `aws --endpoint-url ${endpoint} s3 ls s3://${root}/${dir}/ --recursive | awk '{$1=$2=$3=""; print $0}' | sed 's/^[ \t]*//'` >> search_file.txt
        pattern= "20[0-9]{2}[0-1][0-9][0-3][0-9]"
        #	ファイルパターンで検索をかける: パターンはファイル名のみ
        echo "${file/YYYYMMDD/${pattern}}"
        echo `grep -Eo mnt\/market\/deli\/a-pass-eagle\/asp_user\/application_usage_info_au_one_market_20[0-9]{2}[0-1][0-9][0-3][0-9].tsv search_file.txt` > save_list.txt

        #  マッチしたファイル名から当日(前日 - ライフサイクル)のものをsave_arrayに格納
        yyyymmdd=`date '+%Y%m%d' -d "- 30 day"`

        #save_array+="echo `grep 当日(前日 - ライフサイクル)する`"
        for j in `seq -1 ${lifecycle}`; do
            #seqコマンドでライフサイクルを-1づつ繰り返しライフサイクル分の日付を取得する
            yyyymmdd=`date "+%Y%m%d" -d "- ${j} day"`
            #上記で取得したyyyymmddをファイルパターンのYYYYMMDDに当てはめる
            file_name= `echo "${file//20[0-9]{2}[0-1][0-9][0-3][0-9]/${yyyymmdd}}"`
            #YYYYMMDDをライフサイクル期間の日付に置換したフォーマットとファイルパターンで抽出したファイル名を突き合わせ、一致した物（ライフサイクル内の物）はwhite_listに格納
            white_list+= `echo "grep file_name save_list.txt"`
        done

        #比較用変数にディレクトリ名を格納
        comparison_data="${dir}"
        echo "ファイル名取得完了"
    fi
done

#  この時点でarrayには削除対象が残っており、save_arrayには削除対象のファイルが残っている
#  ライフサイクルの範囲外のファイルをdelete_listに格納
for p in ${white_list[@]}; do
  for q in ${array[@]}; do
    if [ "${p}" = "${q}" ] then
      delete_list+=(${q})
    fi
  done
done

#delete_list内のファイルを削除する
for name in ${delete_list[@]};  do
    echo "${name}"
    echo `aws --endpoint-url ${endpoint} s3 ls s3://${root}/${dir}/ --recursive --exclude "*" --include "${name}" --dryrun` >> delete_file.log
done

echo "処理回数 ${counter}" >> ${file_name%.*}.txt

