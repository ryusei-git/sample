root="spmpro-s3-logarchive-bucket"
endpoint="http://192.168.56.105:9090"
csv="../sample.csv"
array=()
comparison_data="null"
white_list=()
delete_list=()
file_name_array=()
yyyymmdd="null"
#バッチ開始処理
file_name="$(basename $0)"
echo "${file_name}を開始しました" >> ${file_name%.*}.txt

#CSVから削除対象の情報を取得　取得先deleteList2.csv
while read row; do
  echo "${row}"
  array+=(`echo ${row}`)
done < ${csv}

#削除条件のデータ配列を0～Nでループ
for i in "${array[@]}";  do
    #カウンター定義
    let counter++

    #フォーマットとライフサイクルを分解
    lifecycle=`echo ${i} | cut -d ',' -f 2`
    lifecycle=`echo ${lifecycle} | sed -e "s/[\r\n]\+//g"`
    echo "${lifecycle}"
    format=`echo ${i} | cut -d ',' -f 1`

    #  ディレクトリ名とファイル名をそれぞれ変数に入れる
    dir=$(dirname ${format})
    file=`echo ${format#${dir}/}`
    file_name_array+=(`echo ${file}`)
    echo "${dir}"
    if [[ ${comparison_data} == ${dir} ]]
        then
            : # 何もしない
        else
            #   ディレクトリを検索する
            #echo "ディレクトリ内のファイル名を取得中"
            echo `aws --endpoint-url http://192.168.56.105:9090 s3 ls s3://${root}${dir}/ --recursive | awk '{$1=$2=$3=""; print $0}' | sed 's/^[ \t]*//'` > search_file.txt
            #	ファイルパターンで検索をかける: パターンはファイル名のみ

            file=`echo ${file//"YYYYMMDD"/"20[0-9]{2}[0-1][0-9][0-3][0-9]"}`
            echo "----${file}----"
            echo `grep -Eo ${file} search_file.txt` > file_list.txt
            #  マッチしたファイル名から当日(前日 - ライフサイクル)のものをsave_arrayに格納
            yyyymmdd=`date '+%Y%m%d' -d "- ${lifecycle} day"`
            echo "${yyyymmdd}"
            #save_array+="echo `grep 当日(前日 - ライフサイクル)する`"
            for j in `seq -1 ${lifecycle}`; do
                #seqコマンドでライフサイクルを-1づつ繰り返しライフサイクル分の日付を取得する
                yyyymmdd=`date "+%Y%m%d" -d "- ${j} day"`
                #上記で取得したyyyymmddをファイルパターンのYYYYMMDDに当てはめる
                file_name=`echo "${file//"20[0-9]{2}[0-1][0-9][0-3][0-9]"/${yyyymmdd}}"`
                #YYYYMMDDをライフサイクル期間の日付に置換したフォーマットとファイルパターンで抽出したファイル名を突き合わせ、一致した物（ライフサイクル内の物）はwhite_listに格納
                echo "${file_name}---"
                echo `grep ${file_name} file_list.txt`
                white_list+=(`grep ${file_name} file_list.txt`)
            done
            #比較用変数にディレクトリ名を格納
            comparison_data="${dir}"
            #echo "ファイル名取得完了"
    fi
done

#ファイル一覧を読み込み
file_name_csv="./file_list.txt"
while read row; do
  file_list+=(`echo ${row}`)
done < ${file_name_csv}

#  この時点でarrayには削除対象が残っており、save_arrayには削除対象のファイルが残っている
#  ライフサイクルの範囲外のファイルをdelete_listに格納
for p in ${white_list[@]}; do
    echo "${p}"
    for q in ${file_list[@]}; do
    echo "${q}"
        if [[ ${p} == ${q} ]]
            then
                echo "~~~~~${q}"
                delete_list+=(`echo ${q}`)
        fi
    done
done
echo "aaaaaaaaaaaaaaa"
#delete_list内に残っているファイルを削除
for name in ${delete_list[@]};  do
    echo "bbbbbbbbbbbbbb"
    echo "${name}"
    #echo aws --endpoint-url ${endpoint} s3 rm s3://${root}${dir}/ --recursive --exclude "*" --include "${name}" --dryrun > delete_file.log
    echo `aws --endpoint-url ${endpoint} s3 rm s3://${root}/${dir}/ --recursive --exclude "*" --include "${name}" --dryrun` >> delete_file.log
done

echo "処理狩猟"