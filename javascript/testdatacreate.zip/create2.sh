#!/bin/bash
#
#######################################################################
#
#       Script Name     :       create2.sh
#       Description     :       Ⅱ-1．不要ファイル削除処理(ライフサイクル) のテスト用データ作成シェル
#       ATTENTION       :       カレントディレクトリはdev-baseを想定、rootは独自に設定すること
#                               削除対象となる日とそれ以前のテストパターン、および未来日の削除を行わないかのテストのため$lifeに3を追加
########################################################################

root="../data/minio/data/spmpro-s3-logarchive-bucket"
csv="./createList2.csv"

echo "#####不要ファイル削除処理(ライフサイクル)テストデータを作成します。"
start_time=`date "+%s"`

counter=0
array=()

while read row; do
	
	array+=(`echo ${row}`)
done < ${csv}

for i in "${array[@]}"
do
	format=`echo ${i} | cut -d ',' -f 1`
	lifecycle=`echo ${i} | cut -d ',' -f 2`
	lifecycle=`echo ${lifecycle} | sed -e "s/[\r\n]\+//g"`
	
	dir="${root}$(dirname ${format})"
	fileformat="${root}${format}"
	
	mkdir -p ${dir}
		
	declare -i life
	life=`expr 3 \+ ${lifecycle}`

	for j in `seq -1 ${life}`
	do
		yyyymmdd=`date "+%Y%m%d" -d "- ${j} day"`
		let counter++
		file=`echo ${fileformat/YYYYMMDD/${yyyymmdd}}`
		touch ${file}
		echo "create file: ${file}"
	done
done

end_time=`date "+%s"`
time=$((end_time - start_time))

echo "#####テストデータ作成完了 作成数：${counter} 処理時間: ${time}sec"
