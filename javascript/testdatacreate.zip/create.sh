#!/bin/bash
#
#######################################################################
#
#       Script Name     :       create.sh
#       Description     :       Ⅱ-1．不要ファイル削除処理(機能削除等) のテスト用データ作成シェル
#       ATTENTION       :       カレントディレクトリはdev-baseを想定、rootは独自に設定すること
#
########################################################################

root="../data/minio/data/spmpro-s3-logarchive-bucket"
csv="./cleateList.csv"

echo "#####不要ファイル削除処理(機能削除等)テストデータを作成します。"

counter=0
array=()

while read row; do
	let counter++
	array+=(`echo ${row}`)
done < ${csv}

for i in "${array[@]}"
do
	dir="${root}$(dirname ${i})"
	file="${root}${i}"
	mkdir -p ${dir} && touch ${file}
	echo "create file : ${file}"
done

echo "#####テストデータ作成完了 作成数：${counter}"
