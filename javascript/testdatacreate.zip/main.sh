#!/bin/bash
#
#######################################################################
#
#       Script Name     :       main.sh
#       Description     :       Ⅱ-1．不要ファイル削除処理のテスト用データ作成シェル
#       ATTENTION       :       ライフサイクル及び機能削除の両方を同時に実行するスクリプト
#                               create.sh deleteList.csv => 機能削除
#                               create2.sh deleteList2.csv => ライフサイクル
#
########################################################################

bash create.sh
bash create2.sh

